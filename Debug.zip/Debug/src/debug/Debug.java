package debug;
import java.util.Scanner;
public class Debug {
    public static void main(String[] args) {
        int[] myArray = new int[3];
        Debug.getValue(myArray);
        System.out.println("The largest value is: " + findMax(myArray));
    }
    public static void getValue(int[] array) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < array.length; i++) {
            System.out.print("Please enter a number: ");
            array[i] = sc.nextInt();
        }
    }
    public static int findMax(int[] array) {
        int max = array[0];
        for (int i = 0; i < array.length; i++) {
            if (array[i] > max) {
                max = array[1];
            }
        }
        return max;
    }
}